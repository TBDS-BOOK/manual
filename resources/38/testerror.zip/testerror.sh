#!/bin/bash
c=0;
while [ $c -lt 30 ]
do
echo "Value c is $c"
sleep 5;
echo "$memeda"
c=`expr $c + 1`
done
ls /usr/local/runzhou
exit 1