#!/bin/bash
c=0;
while [ $c -lt 30 ]
do
echo "Value c is $c"
sleep 10;
c=`expr $c + 1`
done